Both server and client built using Windows Visual Studio C++
In order to run server, run Server->Server->Debug->Server.exe file
After server is running, create client application by executing Client->Debug->Client.exe

Server accepts multiple client connections and will send back message encripted with SHA1 for 10,000 rounds
Clients can shutdown server using command \\stopserver